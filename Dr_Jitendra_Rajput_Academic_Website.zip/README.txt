DR. JITENDRA RAJPUT — ACADEMIC WEBSITE

1. Open index.html in a web browser to preview the website.
2. Replace the JR initials circle with your professional photograph if desired.
3. Add your official institutional email and verified ORCID/Scopus/Web of Science links.
4. This is a standalone responsive website starter. It is not yet published on the public internet.
5. To make it live, upload the files to a web host or recreate the sections in Google Sites.
   Google Sites does not directly import a complete HTML website as an editable Sites project.

All biography and education details included here are based on information previously provided.
